
import FilesFolderpage from "@/components/FilesFolder/FilesFolder"


function FilesFolder() {
  return (
    <FilesFolderpage/>
  )
}

export default FilesFolder