import { lazy } from "react";

const Login = lazy(() => import("./Login"));

export {Login};
