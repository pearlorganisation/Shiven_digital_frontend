import { lazy } from "react";

const MessageModal = lazy(() => import("./MessageModal"));

export { MessageModal };
